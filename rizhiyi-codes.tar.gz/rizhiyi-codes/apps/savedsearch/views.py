# wangqiushi (wang.qiushi@yottabyte.cn)
# 2014/07/22
# Copyright 2014 Yottabyte
# file description : views.py.

__author__ = 'wangqiushi'
from django.shortcuts import render
