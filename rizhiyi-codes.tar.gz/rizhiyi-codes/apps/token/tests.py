__author__ = 'wangqiushi'
from django.test import TestCase
from tastypie.test import ResourceTestCase
from yottaweb.apps.auth.resources import AuthResource


class TokenResourceTest(ResourceTestCase):
    pass